package com.example.echochair;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;
    private static final int REQUEST_PERMISSION_CODE = 123;

    BluetoothAdapter bluetoothAdapter;
    BluetoothDevice device;
    BluetoothSocket bluetoothSocket;
    OutputStream outputStream;

    ImageView btnMic, bluetoothIcon;
    Button btnForward, btnBackward, btnLeft, btnRight, btnStop, btnDisconnect;

    UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // TESTING mode flag
    boolean TESTING_MODE = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        bluetoothIcon = findViewById(R.id.bluetoothIcon);
        btnMic = findViewById(R.id.btnMic);
        btnForward = findViewById(R.id.btnForward);
        btnBackward = findViewById(R.id.btnBackward);
        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        btnStop = findViewById(R.id.btnStop);
        btnDisconnect = findViewById(R.id.btnDisconnect);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        bluetoothIcon.setOnClickListener(v -> connectToBluetooth());
        btnDisconnect.setOnClickListener(v -> disconnectBluetooth());

        btnForward.setOnClickListener(v -> sendCommand("forward"));
        btnBackward.setOnClickListener(v -> sendCommand("backward"));
        btnLeft.setOnClickListener(v -> sendCommand("left"));
        btnRight.setOnClickListener(v -> sendCommand("right"));

        // ✅ STOP button click listener with confirmation
        btnStop.setOnClickListener(v -> sendCommand("Stop"));

        btnMic.setOnClickListener(v -> startVoiceRecognition());
    }

    private void connectToBluetooth() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSION_CODE);
            return;
        }

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (!pairedDevices.isEmpty()) {
            device = pairedDevices.iterator().next();
            try {
                bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
                bluetoothSocket.connect();
                outputStream = bluetoothSocket.getOutputStream();
                Toast.makeText(this, "Bluetooth Connected", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(this, "Connection Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disconnectBluetooth() {
        try {
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
                Toast.makeText(this, "Disconnected", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendCommand(String command) {
        Log.d("ECHO_CHAIR", "Command to send: " + command);

        if (TESTING_MODE) {
            Toast.makeText(this, "" + command, Toast.LENGTH_SHORT).show();
            return;
        }

        if (outputStream != null) {
            try {
                outputStream.write(command.getBytes());
                Toast.makeText(this, "Sent: " + command, Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                Toast.makeText(this, "Error sending command", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Bluetooth not connected", Toast.LENGTH_SHORT).show();
        }
    }

    private void startVoiceRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak command...");

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input not supported", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String voiceCommand = result.get(0).toLowerCase();

            switch (voiceCommand) {
                case "forward":
                    sendCommand("forward");
                    break;
                case "backward":
                    sendCommand("backward");
                    break;
                case "left":
                    sendCommand("left");
                    break;
                case "right":
                    sendCommand("right");
                    break;
                case "stop":
                    sendCommand("stop");
                    break;
                default:
                    Toast.makeText(this, "Unknown command: " + voiceCommand, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
